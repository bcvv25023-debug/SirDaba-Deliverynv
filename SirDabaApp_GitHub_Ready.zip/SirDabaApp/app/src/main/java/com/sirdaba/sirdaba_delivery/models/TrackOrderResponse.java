package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;

public class TrackOrderResponse {
    public boolean success;
    public TrackData data;
    public String message;

    public static class TrackData {
        @SerializedName("order_code") public String orderCode;
        public String status;
        @SerializedName("distributor_name") public String distributorName;
        @SerializedName("distributor_phone") public String distributorPhone;
        public double lat;
        public double lng;
    }
}

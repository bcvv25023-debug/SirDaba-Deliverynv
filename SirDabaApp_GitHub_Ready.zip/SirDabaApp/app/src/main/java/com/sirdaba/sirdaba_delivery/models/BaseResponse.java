package com.sirdaba.sirdaba_delivery.models;

public class BaseResponse {
    public boolean success;
    public String message;
}

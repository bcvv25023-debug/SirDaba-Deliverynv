package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;

public class AppNotification {
    public int id;
    public String type;
    public String title;
    public String message;
    @SerializedName("created_at") public String createdAt;
    @SerializedName("formatted_date") public String formattedDate;
    @SerializedName("is_read") public boolean isRead;
    @SerializedName("order_id") public int orderId;
    @SerializedName("icon_class") public String iconClass;
}

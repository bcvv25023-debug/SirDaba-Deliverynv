package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;

public class JwtResponse {
    public boolean success;
    @SerializedName("data")
    public JwtData data;

    public static class JwtData {
        public String token;
        @SerializedName("user_email")
        public String userEmail;
        @SerializedName("user_nicename")
        public String userNicename;
        @SerializedName("user_display_name")
        public String userDisplayName;
    }
}

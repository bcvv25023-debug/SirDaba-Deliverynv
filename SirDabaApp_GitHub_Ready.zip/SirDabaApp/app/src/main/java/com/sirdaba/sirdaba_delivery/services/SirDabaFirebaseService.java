package com.sirdaba.sirdaba_delivery.services;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.onesignal.OneSignal;
import com.sirdaba.sirdaba_delivery.R;
import com.sirdaba.sirdaba_delivery.SirDabaApp;
import com.sirdaba.sirdaba_delivery.api.SirDabaRepository;
import com.sirdaba.sirdaba_delivery.ui.dashboard.DashboardActivity;
import com.sirdaba.sirdaba_delivery.utils.TokenManager;

import java.util.Map;
import java.util.Random;

public class SirDabaFirebaseService extends FirebaseMessagingService {

    private static final String TAG = "SirDabaFCM";

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        Log.d(TAG, "New FCM token: " + token);

        // حفظ الـ token محلياً
        getSharedPreferences("sirdaba", MODE_PRIVATE)
            .edit().putString("fcm_token", token).apply();

        // تسجيل الـ token مع السيرفر إذا كان المستخدم مسجل دخوله
        if (TokenManager.isLoggedIn(this)) {
            new SirDabaRepository(this).registerFcmToken(
                token,
                new SirDabaRepository.Callback<>() {
                    @Override public void onSuccess(Object data) {
                        Log.d(TAG, "FCM token registered with server ✓");
                    }
                    @Override public void onError(String message) {
                        Log.e(TAG, "FCM token registration failed: " + message);
                    }
                }
            );
        }
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);

        Map<String, String> data = message.getData();

        String title   = data.getOrDefault("title",    null);
        String body    = data.getOrDefault("body",     null);
        String type    = data.getOrDefault("type",     "general");
        String url     = data.getOrDefault("url",      "");
        String orderId = data.getOrDefault("order_id", "");
        String city    = data.getOrDefault("city",     "");

        // Fallback to notification payload
        if (message.getNotification() != null) {
            if (title == null) title = message.getNotification().getTitle();
            if (body  == null) body  = message.getNotification().getBody();
        }

        if (title == null || title.trim().isEmpty()) title = "SirDaba Delivery";
        if (body  == null || body.trim().isEmpty())  body  = "إشعار جديد";

        Log.d(TAG, "Message | type=" + type + " city=" + city + " orderId=" + orderId);
        showNotification(title, body, url, type, orderId);
    }

    private void showNotification(String title, String body, String url,
                                   String type, String orderId) {

        // التحقق من إذن الإشعارات (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
            && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
               != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Notification permission not granted; skipping.");
            return;
        }

        String channelId = "new_order".equals(type)
            ? SirDabaApp.CHANNEL_ORDERS
            : SirDabaApp.CHANNEL_GENERAL;

        // Intent يفتح DashboardActivity مع بيانات الطلب
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (!url.isEmpty())     intent.putExtra("url",      url);
        if (!orderId.isEmpty()) intent.putExtra("order_id", orderId);
        intent.putExtra("notif_type", type);

        int reqCode = new Random().nextInt(100000);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, reqCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setSound(soundUri)
            .setColor(ContextCompat.getColor(this, R.color.orange_primary))
            .setPriority("new_order".equals(type)
                ? NotificationCompat.PRIORITY_MAX
                : NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent);

        if ("new_order".equals(type)) {
            builder.setCategory(NotificationCompat.CATEGORY_MESSAGE);
            builder.setVibrate(new long[]{0, 400, 200, 400, 200, 400});
        }

        NotificationManagerCompat.from(this).notify(reqCode, builder.build());
        Log.d(TAG, "Notification posted | channel=" + channelId);
    }

    // Helper static: يُستدعى من SirDabaApp لإنشاء القنوات
    public static void createChannelsIfNeeded(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            NotificationChannel orders = new NotificationChannel(
                SirDabaApp.CHANNEL_ORDERS, "طلبات التوصيل",
                NotificationManager.IMPORTANCE_HIGH);
            orders.enableVibration(true);
            nm.createNotificationChannel(orders);

            NotificationChannel general = new NotificationChannel(
                SirDabaApp.CHANNEL_GENERAL, "إشعارات عامة",
                NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(general);
        }
    }
}

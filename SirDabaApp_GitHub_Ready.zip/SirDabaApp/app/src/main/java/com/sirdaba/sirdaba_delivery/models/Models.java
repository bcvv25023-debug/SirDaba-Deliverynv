package com.sirdaba.sirdaba_delivery.models;

/**
 * Point d'entrée historique du package models.
 * Les modèles sont maintenant répartis dans des fichiers séparés publics
 * afin de respecter les règles de compilation Java.
 */
final class Models {
    private Models() {
    }
}

package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;

public class BootstrapResponse {
    public boolean success;
    public BootstrapData data;

    public static class BootstrapData {
        @SerializedName("site_url") public String siteUrl;
        @SerializedName("site_name") public String siteName;
        @SerializedName("nonce") public String nonce;
        @SerializedName("rest_base") public String restBase;
        @SerializedName("ajax_url") public String ajaxUrl;
        @SerializedName("device_token_url") public String deviceTokenUrl;
        public PushConfig push;
    }

    public static class PushConfig {
        public boolean enabled;
        @SerializedName("native_enabled") public boolean nativeEnabled;
        @SerializedName("firebase_native") public FirebaseNative firebaseNative;
    }

    public static class FirebaseNative {
        @SerializedName("apiKey") public String apiKey;
        @SerializedName("projectId") public String projectId;
        @SerializedName("messagingSenderId") public String messagingSenderId;
        @SerializedName("android_app_id") public String androidAppId;
        @SerializedName("appId") public String appId;
        @SerializedName("storageBucket") public String storageBucket;
    }
}

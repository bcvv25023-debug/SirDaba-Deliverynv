package com.sirdaba.sirdaba_delivery.models;

import java.util.List;

public class OrdersResponse {
    public boolean success;
    public List<Order> orders;
    public String message;
}

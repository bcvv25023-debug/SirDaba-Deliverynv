package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;

public class UserResponse {
    public boolean success;
    public UserData data;

    public static class UserData {
        public int id;
        @SerializedName("full_name") public String fullName;
        public String name;
        public String email;
        public String phone;
        public String city;
        public String address;
        @SerializedName("user_type") public String userType;
        @SerializedName("is_approved") public int isApproved;
        @SerializedName("wallet_balance") public double walletBalance;
        @SerializedName("profile_image") public String profileImage;
        public String nonce;
        public String status;
    }
}
